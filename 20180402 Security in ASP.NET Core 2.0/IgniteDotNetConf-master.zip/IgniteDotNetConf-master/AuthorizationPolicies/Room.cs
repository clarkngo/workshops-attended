﻿namespace AuthorizationPolicies
{
    public class Room
    {
        public string Number { get; set; }
    }
}
