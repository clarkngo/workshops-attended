Sample code for DotNetConf and Ignite 2017
